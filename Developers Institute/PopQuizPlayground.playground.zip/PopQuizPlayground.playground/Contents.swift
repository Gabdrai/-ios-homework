//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

/* How do you print the string above? */


/* Name some basic data types. */

/* What is the difference between an array and a dictionary? */


/* Create a class for a Person with name, age, height, gender, and race as its properties */


/* Describe and/or code binary search. */


/* Imagine you have two array a = [1,2,3,4,5] and b =[3,2,9,3,7], write a function to find out common elements in both array. */



